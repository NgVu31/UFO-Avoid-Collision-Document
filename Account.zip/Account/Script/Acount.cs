using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Acount : MonoBehaviour
{
    public TMP_InputField edtUser, edtPass;
    public TMP_Text txtError;
    public Selectable first;
    private EventSystem eventSystem;
    public Button Login;
    // Start is called before the first frame update
    void Start()
    {
        eventSystem = EventSystem.current;
        first.Select();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Return)) 
        {
            Login.onClick.Invoke();
        }
    }
    public void Checklogin()
    {
        var user = edtUser.text;
        var pass = edtPass.text;

        if (user.Equals("Shen") && pass.Equals("6666"))
        {
            SceneManager.LoadScene(0);
        }
        else
        {
            txtError.text = "Login failed!";
        }
    }
}

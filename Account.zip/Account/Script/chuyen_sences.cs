using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class chuyen_sences : MonoBehaviour
{
    public void play()
    {
        SceneManager.LoadScene(1);
    }
    public void play2()
    {
        SceneManager.LoadScene(3);
    }
    public void vemenu()
    {
        SceneManager.LoadScene(0);
    }
    public void chonman()
    {
        SceneManager.LoadScene(2);
    }
    public void home()
    {
        SceneManager.LoadScene(0);
    }
    public void replay()
    {
        SceneManager.LoadScene(1);
    }
    public void replay2()
    {
        SceneManager.LoadScene(3);
    }
    public void shop()
    {
        SceneManager.LoadScene(4);
    }
    public void dailyshop()
    {
        SceneManager.LoadScene(6);
    }
    public void gacha()
    {
        SceneManager.LoadScene(5);
    }
    public void setting()
    {
        SceneManager.LoadScene(7);
    }
    public void highScore()
    {
        SceneManager.LoadScene(8);
    }
    public void outtt()
    {
        Application.Quit();
    }
    public void back()
    {
        SceneManager.LoadScene(1);
    }
    public void tamdung()
    {
        SceneManager.LoadScene(9);
    }
    public void back2()
    {
        SceneManager.LoadScene(0);
    }
    public void Signup()
    {
        SceneManager.LoadScene(11);
    }
    public void back3()
    {
        SceneManager.LoadScene(10);
    }
}
